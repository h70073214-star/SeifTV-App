const items=[
 {title:"ليالي المدينة",type:"مسلسل",cat:"دراما"},
 {title:"رحلة أخيرة",type:"فيلم",cat:"مغامرات"},
 {title:"خط العودة",type:"مسلسل",cat:"أكشن"},
 {title:"الحكاية الجديدة",type:"مسلسل",cat:"رومانسي"},
 {title:"وقت الصفر",type:"فيلم",cat:"إثارة"},
 {title:"الطريق الطويل",type:"فيلم",cat:"دراما"}
];

function card(item){
 return `<article class="card" onclick="openPlayer('${item.title}')">
   <div class="poster">▶</div>
   <h3>${item.title}</h3><p>${item.type} • ${item.cat}</p>
 </article>`;
}
function render(){
 document.getElementById('latest').innerHTML=items.map(card).join('');
 document.getElementById('continue').innerHTML=items.slice(0,3).map(card).join('');
 document.getElementById('categories').innerHTML=[...new Set(items.map(x=>x.cat))].map(c=>`<button class="chip" onclick="filterCat('${c}')">${c}</button>`).join('');
}
function filterCat(cat){
 const found=items.filter(x=>x.cat===cat);
 document.getElementById('latest').innerHTML=found.map(card).join('');
 window.scrollTo({top:0,behavior:'smooth'});
}
function showAll(){document.getElementById('latest').innerHTML=items.map(card).join('')}
function openPlayer(title){
 localStorage.setItem('seif_tv_last',title);
 alert('مشغل تجريبي: '+title+'\nأضف رابط فيديو تملكه أو تملك ترخيصه داخل التطبيق.');
}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
function search(){
 const q=document.getElementById('searchInput').value.trim().toLowerCase();
 document.getElementById('searchResults').innerHTML=items.filter(x=>x.title.toLowerCase().includes(q)||x.cat.toLowerCase().includes(q)).map(x=>`<div class="result">${x.title} — ${x.type}</div>`).join('')||'<div class="result">لا توجد نتائج</div>';
}
document.getElementById('searchBtn').onclick=()=>{
 document.getElementById('modal').classList.remove('hidden');
 document.getElementById('searchInput').focus();
};
document.getElementById('searchInput').addEventListener('input',search);
document.querySelectorAll('.bottom button').forEach(b=>b.onclick=()=>alert('القسم: '+b.dataset.nav));
render();
