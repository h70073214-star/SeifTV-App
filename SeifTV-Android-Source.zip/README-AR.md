# Seif TV

مشروع Android تجريبي لتطبيق مشاهدة محتوى مرخّص باسم Seif TV.

## البناء
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Java 17
- compileSdk 35
- minSdk 23

ملف `codemagic.yaml` مجهز للبناء على Codemagic.

> استخدم فقط الفيديوهات والصور والبيانات التي تملك حقوق استخدامها.
